export { default } from "#symbol/config";
