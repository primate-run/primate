export { default } from "#database/config";
