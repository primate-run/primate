// exposure
export type { default as ResponseLike } from "#response/ResponseLike";

export { default } from "#module/NextRoute";
