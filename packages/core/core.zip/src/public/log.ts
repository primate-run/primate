export { default } from "#log";
