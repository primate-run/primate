export { default } from "#route";
