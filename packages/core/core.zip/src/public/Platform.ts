export { default } from "#platform/Platform";
