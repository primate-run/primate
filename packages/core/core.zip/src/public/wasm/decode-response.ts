import decodeResponse from "#wasm/decode-response";

export default decodeResponse;