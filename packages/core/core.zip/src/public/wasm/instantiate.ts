import instantiate from "#wasm/instantiate";
export default instantiate;

export type * from "#wasm/instantiate";
