import encodeSession from "#wasm/encode-session";

export default encodeSession;
