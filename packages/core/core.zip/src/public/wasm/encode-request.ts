import encodeRequest from "#wasm/encode-request";

export default encodeRequest;
