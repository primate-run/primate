export { default } from "#module/BuildHook";
