export { default } from "#location";
