export { default } from "#config/index";
