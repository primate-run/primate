export { default } from "#frontend/ViewResponse";
