export { default } from "#frontend/Module";
