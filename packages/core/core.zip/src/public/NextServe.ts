export { default } from "#module/NextServe";
