export { default } from "#database/DataDict";
