export { default } from "#database/TypeMap";
