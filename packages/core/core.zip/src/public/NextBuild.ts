export { default } from "#module/NextBuild";
