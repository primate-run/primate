export { default } from "#inline";
