export { default } from "#client/spa/index";
