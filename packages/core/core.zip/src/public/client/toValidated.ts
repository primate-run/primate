export { default } from "#client/toValidated";
