export { default } from "#response/view";
