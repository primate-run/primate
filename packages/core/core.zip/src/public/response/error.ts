export { default } from "#response/error";
