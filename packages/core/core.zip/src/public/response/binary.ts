export { default } from "#response/binary";
