export { default } from "#response/text";
