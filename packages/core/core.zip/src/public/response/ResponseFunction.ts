export { default } from "#response/ResponseFunction";
