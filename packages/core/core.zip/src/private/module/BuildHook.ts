import type BuildApp from "#BuildApp";
import type Hook from "#module/Hook";

type BuildHook = Hook<BuildApp>;

export type { BuildHook as default };
