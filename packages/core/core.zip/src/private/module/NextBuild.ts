import type BuildApp from "#BuildApp";
import type Next from "#module/Next";

type NextBuild = Next<BuildApp>;

export type { NextBuild as default };
