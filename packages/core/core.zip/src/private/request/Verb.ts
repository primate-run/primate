import type verbs from "#request/verbs";

type Verb = typeof verbs[number];

export type { Verb as default };
