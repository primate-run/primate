type Mode = "development" | "production" | "testing";

export { Mode as default };
