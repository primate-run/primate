
export default interface Style {
  code: string;
  href?: string;
  inline: boolean;
}
