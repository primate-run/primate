export default interface Font {
  as: string;
  crossorigin: string;
  href: string;
  rel: "preload";
  type: string;
}
