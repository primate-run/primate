export default Symbol("@primate/core/symbol/config");
