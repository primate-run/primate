export default Symbol("@primate/core/symbol/layout-depth");
