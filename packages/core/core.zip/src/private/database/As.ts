import type Types from "#database/Types";

type As = {
  name: string;
  types: Types;
};

export type { As as default };
