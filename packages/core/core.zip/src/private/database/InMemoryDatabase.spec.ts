import test from "#database/test";
import InMemoryDatabase from "#database/InMemoryDatabase";

test(new InMemoryDatabase());
