import type DataType from "pema/DataType";

type DataKey = keyof DataType;

export type { DataKey as default };
