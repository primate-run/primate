import AsyncLocalStorage from "@rcompat/async/context";

export default new AsyncLocalStorage();
