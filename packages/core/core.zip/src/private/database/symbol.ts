export default Symbol("@primate/core/database");
