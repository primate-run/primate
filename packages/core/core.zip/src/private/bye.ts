import dim from "@rcompat/cli/color/dim";
import yellow from "@rcompat/cli/color/yellow";
import print from "@rcompat/cli/print";

export default () => print(dim(yellow("~~ bye\n")));
