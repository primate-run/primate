import config from "primate/config";

export default config();
