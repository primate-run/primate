import session from "primate/config/session";

export default session();
