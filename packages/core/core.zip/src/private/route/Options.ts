type RouteOptions = {
  parseBody?: boolean;
};

export type { RouteOptions as default };
