import type Asset from "#asset/Asset";
import type Config from "#config/Config";
import type Loader from "#Loader";
import type Mode from "#Mode";
import type SessionConfig from "#session/Config";
import type Dict from "@rcompat/type/Dict";
import type Schema from "pema/Schema";

type Import = {
  default: unknown;
} & Dict;

type BuildFiles = {
  locales?: [string, Dict<string>][];
  routes: [string, { default: any }][];
  stores?: [string, {
    default: Schema;
    name?: string;
  }][];
};

type ServeInit = {
  assets: Asset[];
  components?: [string, Import][];
  config: Config;
  files: BuildFiles;
  loader: Loader;
  mode: Mode;
  platform: string;
  session_config: SessionConfig;
};

export type { ServeInit as default };
