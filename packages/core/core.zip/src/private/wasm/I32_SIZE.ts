export default Int32Array.BYTES_PER_ELEMENT;
