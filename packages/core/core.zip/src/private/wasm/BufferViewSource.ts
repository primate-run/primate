import type BufferView from "@rcompat/bufferview";

type BufferViewSource = ConstructorParameters<typeof BufferView>;

export type { BufferViewSource as default };
