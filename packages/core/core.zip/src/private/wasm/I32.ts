/** The default request and response types, which are likely pointers into a
 * WASM linear memory space. */
type I32 = number;

export type { I32 as default };
