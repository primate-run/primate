type BindingContext = "components" | "config" | "modules" | "routes" | "stores";

export type { BindingContext as default };
