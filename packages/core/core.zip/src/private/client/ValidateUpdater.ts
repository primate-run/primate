type ValidateUpdater<T> = (previous: T) => T;

export type { ValidateUpdater as default };
